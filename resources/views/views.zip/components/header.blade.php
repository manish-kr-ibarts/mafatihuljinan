<header class="top-0 z-20 py-3 flex items-center justify-between">
    <!-- Left Section: Menu + Page Title -->
    <div class="flex items-center space-x-4">
        <!-- Page Title -->
        <h1 class="text-2xl font-bold text-[#034E7A]">{{ $pageName ?? 'Dashboard' }}</h1>
    </div>
<!-- 
    <div class="flex items-center space-x-4">
        <div class="relative hidden md:flex">
            <input type="text" placeholder="Search..." 
                   class="pl-10 pr-3 py-1 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        </div>

        <button class="relative text-gray-600 hover:text-gray-900">
            <i class="fas fa-bell text-lg"></i>
            <span class="absolute top-0 right-0 inline-block w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        <button class="text-gray-600 hover:text-gray-900">
            <i class="fas fa-envelope text-lg"></i>
        </button>

        <button id="themeToggle" class="text-gray-600 hover:text-gray-900">
            <i class="fas fa-sun text-lg"></i>
        </button>
    </div>
-->
</header>
<hr>